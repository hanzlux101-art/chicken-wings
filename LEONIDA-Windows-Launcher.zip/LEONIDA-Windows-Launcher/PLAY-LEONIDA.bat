@echo off
setlocal
set "GAME_DIR=%LOCALAPPDATA%\LEONIDA\leonida-main"
if not exist "%GAME_DIR%\dist\index.html" (
  echo LEONIDA is not installed yet. Run INSTALL-LEONIDA.bat first.
  pause
  exit /b 1
)
cd /d "%GAME_DIR%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0play-leonida.ps1" -GameDir "%GAME_DIR%"
