LEONIDA — WINDOWS QUICK START

1. Extract this ZIP to a normal folder, for example Desktop\LEONIDA.
2. Double-click INSTALL-LEONIDA.bat once.
   - It checks for Node.js 20+ and attempts to install Node.js LTS using winget if needed.
   - It downloads the official source from bridge-mind/leonida.
   - It installs dependencies and compiles the production build.
3. Whenever you want to play, double-click PLAY-LEONIDA.bat.
4. A browser opens to the game. Keep the launcher window open while playing; closing it stops the local server.

REQUIREMENTS
- Windows 10/11, internet for first setup, Node.js 20+ (the installer can use winget), and a desktop browser with WebGL2.
- The game is a browser game, not a native Windows .exe. The compiled files are stored in:
  %LOCALAPPDATA%\LEONIDA\leonida-main\dist

CONTROLS
- Click the game to capture the mouse; Esc releases it / opens pause.
- WASD move, mouse look, Shift sprint, Space jump.
- F enter/exit vehicles, E interact, M map, Up Arrow phone, F3 performance overlay.
- See the project's CONTROLS.md for the full control list.

TROUBLESHOOTING
- If winget is unavailable, install Node.js LTS from https://nodejs.org/, reopen Windows Terminal, then rerun INSTALL-LEONIDA.bat.
- If setup fails during npm ci, check internet access and rerun INSTALL-LEONIDA.bat.
- The project README says desktop Chrome, Edge, or Firefox is supported; mobile is not supported.
- This launcher downloads the latest main branch when setup runs. Running setup again replaces the local source folder and rebuilds it.

PROJECT
https://github.com/bridge-mind/leonida
https://bridge-mind.github.io/leonida/
