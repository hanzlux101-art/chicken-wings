$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$installRoot = Join-Path $env:LOCALAPPDATA 'LEONIDA'
$zipPath = Join-Path $env:TEMP 'leonida-main.zip'
$extractPath = Join-Path $env:TEMP 'leonida-extract'
$gameDir = Join-Path $installRoot 'leonida-main'

Write-Host ''
Write-Host '=== LEONIDA Windows setup ===' -ForegroundColor Cyan
Write-Host 'This downloads the official public source and builds it on this PC.'

$nodeOk = $false
try {
  $nodeVersion = (& node --version 2>$null)
  if ($LASTEXITCODE -eq 0 -and $nodeVersion -match '^v(\d+)\.' -and [int]$Matches[1] -ge 20) { $nodeOk = $true }
} catch {}

if (-not $nodeOk) {
  Write-Host 'Node.js 20 or newer is required. Trying to install the current Node.js LTS with Windows Package Manager...'
  $winget = Get-Command winget -ErrorAction SilentlyContinue
  if (-not $winget) { throw 'Node.js 20+ is missing and winget is unavailable. Install Node.js LTS from https://nodejs.org/, reopen this window, and run INSTALL-LEONIDA.bat again.' }
  winget install --id OpenJS.NodeJS.LTS --exact --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) { throw 'Node.js installation failed. Install Node.js LTS from https://nodejs.org/ and rerun this file.' }
  $nodePath = Join-Path $env:ProgramFiles 'nodejs'
  if (Test-Path $nodePath) { $env:Path = "$nodePath;$env:Path" }
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js was installed. Close this window, open a new one, and run INSTALL-LEONIDA.bat again.' }
}

$nodeVersion = (& node --version)
Write-Host "Using Node.js $nodeVersion" -ForegroundColor Green
New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
if (Test-Path $extractPath) { Remove-Item $extractPath -Recurse -Force }
New-Item -ItemType Directory -Force -Path $extractPath | Out-Null
Write-Host 'Downloading LEONIDA from the official GitHub repository...'
Invoke-WebRequest -Uri 'https://github.com/bridge-mind/leonida/archive/refs/heads/main.zip' -OutFile $zipPath
Expand-Archive -LiteralPath $zipPath -DestinationPath $extractPath -Force
$downloaded = Join-Path $extractPath 'leonida-main'
if (-not (Test-Path (Join-Path $downloaded 'package.json'))) { throw 'The downloaded archive did not contain the expected project files.' }
if (Test-Path $gameDir) { Remove-Item $gameDir -Recurse -Force }
Move-Item -LiteralPath $downloaded -Destination $gameDir
Remove-Item $extractPath -Recurse -Force
Remove-Item $zipPath -Force -ErrorAction SilentlyContinue

Push-Location $gameDir
try {
  Write-Host 'Installing exact project dependencies (npm ci)...' -ForegroundColor Cyan
  npm ci
  if ($LASTEXITCODE -ne 0) { throw 'npm ci failed. Check your internet connection and rerun INSTALL-LEONIDA.bat.' }
  Write-Host 'Compiling the production build (npm run build)...' -ForegroundColor Cyan
  npm run build
  if ($LASTEXITCODE -ne 0) { throw 'The project build failed. The error output above identifies the issue.' }
  if (-not (Test-Path (Join-Path $gameDir 'dist\index.html'))) { throw 'Build completed without creating dist/index.html.' }
} finally { Pop-Location }
Write-Host ''
Write-Host 'LEONIDA has been installed and compiled successfully.' -ForegroundColor Green
Write-Host 'Use PLAY-LEONIDA.bat in this folder whenever you want to play.'
Write-Host 'Install location: ' $gameDir
Write-Host 'Note: this is a browser game; use desktop Chrome, Edge, or Firefox with WebGL2.'
Read-Host 'Press Enter to close'
