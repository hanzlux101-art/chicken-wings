param([Parameter(Mandatory=$true)][string]$GameDir)
$ErrorActionPreference = 'Stop'
$port = 4173
$listener = $null
try {
  $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
  $listener.Start()
  $listener.Stop()
} catch {
  throw "Port $port is already in use. Close the other LEONIDA instance or another app using port $port, then try again."
}
Set-Location $GameDir
$url = "http://127.0.0.1:$port/"
Write-Host 'Starting LEONIDA...' -ForegroundColor Cyan
$server = Start-Process -FilePath 'npm.cmd' -ArgumentList @('run','preview','--','--host','127.0.0.1','--port',"$port",'--strictPort') -WorkingDirectory $GameDir -PassThru -WindowStyle Hidden
try {
  $ready = $false
  for ($i=0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 500
    try { $response = Invoke-WebRequest -Uri $url -TimeoutSec 2; if ($response.StatusCode -eq 200) { $ready = $true; break } } catch {}
    if ($server.HasExited) { throw 'The local game server stopped unexpectedly.' }
  }
  if (-not $ready) { throw 'The game server did not become ready. Try running INSTALL-LEONIDA.bat again.' }
  Write-Host "Opening $url" -ForegroundColor Green
  Start-Process $url
  Write-Host 'Game is running. Close this window to stop the local game server.'
  while (-not $server.HasExited) { Start-Sleep -Seconds 1 }
} finally {
  if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue }
}
